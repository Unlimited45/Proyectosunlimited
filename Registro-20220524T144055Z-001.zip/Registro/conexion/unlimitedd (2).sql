-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 23-05-2022 a las 16:08:44
-- Versión del servidor: 10.4.19-MariaDB
-- Versión de PHP: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `unlimitedd`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carrito_compras`
--

CREATE TABLE `carrito_compras` (
  `ID_carrito` int(11) NOT NULL,
  `subtotal` bigint(20) NOT NULL,
  `Codigo_curso` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `carrito_compras`
--

INSERT INTO `carrito_compras` (`ID_carrito`, `subtotal`, `Codigo_curso`) VALUES
(1, 150000, 1001),
(2, 145000, 1004),
(3, 210000, 1008);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `certificado`
--

CREATE TABLE `certificado` (
  `ID_certificado` int(11) NOT NULL,
  `fecha_fin_curso` date NOT NULL,
  `ID_persona` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `certificado`
--

INSERT INTO `certificado` (`ID_certificado`, `fecha_fin_curso`, `ID_persona`) VALUES
(1, '2023-12-05', 1077721145),
(2, '2023-11-09', 1026447318),
(3, '2022-12-10', 55177272),
(4, '2023-10-14', 1141919520);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cursos`
--

CREATE TABLE `cursos` (
  `Codigo_curso` int(11) NOT NULL,
  `tipo` varchar(30) NOT NULL,
  `duracion` varchar(20) NOT NULL,
  `descripcion` varchar(50) NOT NULL,
  `titulo` varchar(20) NOT NULL,
  `precio` bigint(20) NOT NULL,
  `horario` varchar(20) NOT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_inscripcion` date NOT NULL,
  `calificacion` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `cursos`
--

INSERT INTO `cursos` (`Codigo_curso`, `tipo`, `duracion`, `descripcion`, `titulo`, `precio`, `horario`, `fecha_inicio`, `fecha_inscripcion`, `calificacion`) VALUES
(100, 'virtual', '3 meses', ' te permitirá adquirir las habilidades para el man', 'Microsoft excel', 78000, 'lunes-viernes', '2023-02-10', '2022-11-02', '1/100'),
(1001, 'virtual', '3 meses', 'El curso de Power Point está destinado a la realiz', 'Power point', 78000, 'lunes,martes y viern', '2022-05-20', '2022-06-15', '1/100'),
(1002, 'virtual', '2 meses', 'El objetivo de este curso básico de Word es que lo', 'Microsoft word', 80000, 'lunes y martes', '2022-11-02', '2022-06-12', '1/100'),
(1003, 'virtual', '1 semana', 'Microsoft Teams es una plataforma de comunicación ', 'Microsoft teams', 67000, 'lunes,miercoles y ju', '2022-08-02', '2022-11-14', '1/100'),
(1004, 'virtual', '3 semanas', 'Cualquier mensaje se puede modificar, reutilizar, ', 'correo electronico', 70000, 'Sabado, domingo y lu', '2023-01-20', '2023-02-15', '1/100'),
(1005, 'virtual', '2 semanas', 'Identificar los componentes principales de la inte', 'Drive', 78000, 'lunes,miercoles y vi', '2022-11-02', '2022-11-10', '1/100'),
(1006, 'virtual', '2 semanas', 'Google Classroom es una herramienta creada por Goo', 'Classroom', 55000, 'lunes y martes', '2022-07-14', '2022-08-10', '1/100'),
(1007, 'virtual', '2 semanas', 'Es una plataforma colaborativa para la educación, ', 'territorium', 90000, 'martes y jueves', '2022-11-02', '2023-02-10', '1/100'),
(1008, 'virtual', '1 mes', 'Verificar la oferta de programas disponibles en el', 'Sofia plus', 90000, 'miercoles y viernes', '2022-06-26', '2022-07-05', '1/100');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inicio de sesión`
--

CREATE TABLE `inicio de sesión` (
  `id` int(11) NOT NULL,
  `ID_persona` int(11) NOT NULL,
  `contraseña` varchar(100) NOT NULL,
  `ID_rol` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inquietud`
--

CREATE TABLE `inquietud` (
  `ID_inquietud` int(11) NOT NULL,
  `tipo_inquietud` varchar(100) NOT NULL,
  `solucion` varchar(100) NOT NULL,
  `ID_persona` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `inquietud`
--

INSERT INTO `inquietud` (`ID_inquietud`, `tipo_inquietud`, `solucion`, `ID_persona`) VALUES
(1, 'No se como mirar las evidencias de trabajo', 'deberas irte a la parte de arriba del menu, darle en la opcion evidencia y hay se mostraran las evid', 55177272),
(2, 'No puedo actualizar mi perfil', 'En la parte superior derecha encontraras un icono que dice perfil, le das ahi y te aparecera un menu', 1141919520),
(3, 'no se como mirar las sesiones en linea', 'en la seccion de evidencias, podras observar un apartado que dice material de apoyo y sesiones en li', 1026447318);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `material_apoyo`
--

CREATE TABLE `material_apoyo` (
  `ID_material` int(11) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  `tipo` varchar(20) NOT NULL,
  `descripcion` varchar(100) NOT NULL,
  `ID_persona` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `material_apoyo`
--

INSERT INTO `material_apoyo` (`ID_material`, `nombre`, `tipo`, `descripcion`, `ID_persona`) VALUES
(1, 'guias microsoft word', 'documento', 'En estas guias podra encontrar la introduccion a word', 55177272),
(2, 'powerpoint', 'video', 'En este video podra encontrar todo lo relacionado con power point', 1077721145),
(3, 'territorium', 'guias y videos', 'En este material encontrara lo que tienes que saber de territorium', 1141919520),
(4, 'teams', 'documentos', 'Teams es una plataforma interesante, en este docum', 1026447318),
(5, 'drive', 'video', 'en este video encontraras las funciones de drive', 1077721145);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pago`
--

CREATE TABLE `pago` (
  `ID_pago` int(11) NOT NULL,
  `tipo_de_pago` varchar(50) NOT NULL,
  `valor` bigint(20) NOT NULL,
  `ID_persona` int(11) DEFAULT NULL,
  `ID_carrito` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `pago`
--

INSERT INTO `pago` (`ID_pago`, `tipo_de_pago`, `valor`, `ID_persona`, `ID_carrito`) VALUES
(1, 'Nequi', 54000, 55177272, 2),
(2, 'Tarjeta credito', 85000, 1026447318, 1),
(3, 'Daviplata', 77000, 55177272, 3),
(4, 'Tarjeta debito', 86000, 1077721145, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `permisos`
--

CREATE TABLE `permisos` (
  `ID_permisos` int(11) NOT NULL,
  `nombre_permiso` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `permisos`
--

INSERT INTO `permisos` (`ID_permisos`, `nombre_permiso`) VALUES
(101, 'AGREGAR'),
(102, 'ACTUALIZAR'),
(103, 'LEER'),
(104, 'ELIMINAR');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `persona`
--

CREATE TABLE `persona` (
  `ID_persona` int(11) NOT NULL,
  `nombres` varchar(20) NOT NULL,
  `apellidos` varchar(20) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `edad` smallint(6) NOT NULL,
  `direccion` varchar(30) NOT NULL,
  `telefono` bigint(20) NOT NULL,
  `curriculum_vitae` varchar(100) DEFAULT NULL,
  `correo` varchar(30) NOT NULL,
  `contraseña` varchar(20) NOT NULL,
  `Codigo_curso` int(11) DEFAULT NULL,
  `ID_rol` int(11) DEFAULT NULL,
  `ID_permisos` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `persona`
--

INSERT INTO `persona` (`ID_persona`, `nombres`, `apellidos`, `fecha_nacimiento`, `edad`, `direccion`, `telefono`, `curriculum_vitae`, `correo`, `contraseña`, `Codigo_curso`, `ID_rol`, `ID_permisos`) VALUES
(55177272, 'ana', 'ocampo', '1974-12-25', 47, 'calle 6a#89-47', 3123458571, '', 'yudiocampo123@gmail.com', '12345..', 1005, 3, NULL),
(65554855, 'Daniela', 'Perez lopez', '2002-03-30', 0, 'kr78f 65c 46 s', 3112546306, NULL, 'Danielarojasgutierrez30@gmail.', '12345678d', NULL, NULL, NULL),
(1000160619, 'anderson', 'samudio', '2002-12-03', 19, 'clle 42a 89-51', 3205868288, NULL, 'gort3052@gmail.com', 'tre2345', 1005, 2, NULL),
(1000810993, 'lorena', 'pineda', '2003-10-31', 18, 'crra77g75-98', 3123127571, NULL, 'wendylorenagonzalez@gmail.com', '123456', 1005, 2, NULL),
(1021336233, 'juanito', 'perez garcia', '2002-12-06', 0, 'kr36f #65c 46Sur', 3214568945, NULL, 'juanitop@gmail.com', '12345', NULL, NULL, NULL),
(1021394725, 'daniela', 'GUTIERREZ', '2002-03-30', 0, 'cra38 f 65 c', 3214144627, NULL, 'danigugmail.com', '123456', NULL, NULL, NULL),
(1021394728, 'daniela', 'rojas', '2004-03-30', 18, 'cr78f65c45', 3214144627, NULL, 'danielarojas@gmail.com', 'unlimited1234', 1005, 2, NULL),
(1023645265, 'sebastian', 'rodrigues sierra', '2005-03-30', 0, 'kr78f 65c 46', 3112546306, NULL, 'sebastianro@gmail.com', '123456d', NULL, NULL, NULL),
(1026447318, 'paola', 'pinzon', '2000-03-09', 21, 'calle 9a #02-7', 3112700441, '', 'yydain@outlook.es', '11235', 1002, 2, NULL),
(1077721145, 'leonel', 'alvarez', '1998-02-08', 22, 'carerra 7 #77D 6', 3004552117, 'Conocimientos en softwares de productividad para equipos, procedimientos presupuestarios departament', 'leoleo@gmail.com', '12210', NULL, 1, NULL),
(1077721149, 'kristell', 'silva', '2004-09-06', 17, 'calle 6a 89-47', 3192111019, NULL, 'kristellsilva@gmail.com', '321015', 1005, 2, NULL),
(1141919520, 'pedro', 'paez', '1957-07-24', 65, 'calle 5D #44-78', 3205547796, ' Los resultados de mis alumnos son lo primero. Por eso he desarrollado mi método de enseñanza enfoca', 'paezpedro@hotmail.com', '85200', 1007, 2, NULL),
(1234567891, 'camilo', 'Perez lopez', '2000-06-20', 0, 'kr36f #65c 46Sur', 3546982345, NULL, 'camilolopez@gmail.com', '123456789', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rol`
--

CREATE TABLE `rol` (
  `ID_rol` int(11) NOT NULL,
  `nombre_rol` varchar(30) NOT NULL,
  `descripcion` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `rol`
--

INSERT INTO `rol` (`ID_rol`, `nombre_rol`, `descripcion`) VALUES
(1, 'Administrador', 'El que administra la pagina web'),
(2, 'Usuario', 'El que ingresa a la pagina web'),
(3, 'Profesor', 'El que acompaña a los usuarios con los cursos'),
(4, 'Asesor', 'El que responde inquietudes');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sesiones_en_linea`
--

CREATE TABLE `sesiones_en_linea` (
  `ID_sesiones` int(11) NOT NULL,
  `tema` varchar(50) NOT NULL,
  `hora` time DEFAULT NULL,
  `link` varchar(50) NOT NULL,
  `ID_persona` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `sesiones_en_linea`
--

INSERT INTO `sesiones_en_linea` (`ID_sesiones`, `tema`, `hora`, `link`, `ID_persona`) VALUES
(1, 'analizar las actividades subidas', '14:10:00', 'https://meet.google.com/_meet/hty-mqkx-sgu?pli=1&i', 1077721145),
(2, 'resolver problematicas', '15:00:00', 'https://meet.google.com/vun-oekb-vzy?pli=1', 1141919520),
(3, 'explicacion taller', '12:00:00', 'https://meet.google.com/edq-vhoz-noe', 1026447318);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `carrito_compras`
--
ALTER TABLE `carrito_compras`
  ADD PRIMARY KEY (`ID_carrito`),
  ADD KEY `fk_cursos` (`Codigo_curso`);

--
-- Indices de la tabla `certificado`
--
ALTER TABLE `certificado`
  ADD PRIMARY KEY (`ID_certificado`),
  ADD KEY `fk_person` (`ID_persona`);

--
-- Indices de la tabla `cursos`
--
ALTER TABLE `cursos`
  ADD PRIMARY KEY (`Codigo_curso`);

--
-- Indices de la tabla `inicio de sesión`
--
ALTER TABLE `inicio de sesión`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ID_rol` (`ID_rol`),
  ADD KEY `ID_persona` (`ID_persona`);

--
-- Indices de la tabla `inquietud`
--
ALTER TABLE `inquietud`
  ADD PRIMARY KEY (`ID_inquietud`),
  ADD KEY `fk_gentee` (`ID_persona`);

--
-- Indices de la tabla `material_apoyo`
--
ALTER TABLE `material_apoyo`
  ADD PRIMARY KEY (`ID_material`),
  ADD KEY `fk_per` (`ID_persona`);

--
-- Indices de la tabla `pago`
--
ALTER TABLE `pago`
  ADD PRIMARY KEY (`ID_pago`),
  ADD KEY `fk_gente` (`ID_persona`),
  ADD KEY `fk_carrito` (`ID_carrito`);

--
-- Indices de la tabla `permisos`
--
ALTER TABLE `permisos`
  ADD PRIMARY KEY (`ID_permisos`);

--
-- Indices de la tabla `persona`
--
ALTER TABLE `persona`
  ADD PRIMARY KEY (`ID_persona`),
  ADD KEY `fk_curso` (`Codigo_curso`),
  ADD KEY `fk_rol` (`ID_rol`),
  ADD KEY `fk_permisos` (`ID_permisos`);

--
-- Indices de la tabla `rol`
--
ALTER TABLE `rol`
  ADD PRIMARY KEY (`ID_rol`);

--
-- Indices de la tabla `sesiones_en_linea`
--
ALTER TABLE `sesiones_en_linea`
  ADD PRIMARY KEY (`ID_sesiones`),
  ADD KEY `fk_personaa` (`ID_persona`);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `carrito_compras`
--
ALTER TABLE `carrito_compras`
  ADD CONSTRAINT `fk_cursos` FOREIGN KEY (`Codigo_curso`) REFERENCES `cursos` (`Codigo_curso`);

--
-- Filtros para la tabla `certificado`
--
ALTER TABLE `certificado`
  ADD CONSTRAINT `fk_person` FOREIGN KEY (`ID_persona`) REFERENCES `persona` (`ID_persona`);

--
-- Filtros para la tabla `inicio de sesión`
--
ALTER TABLE `inicio de sesión`
  ADD CONSTRAINT `inicio de sesión_ibfk_1` FOREIGN KEY (`ID_rol`) REFERENCES `rol` (`ID_rol`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `inicio de sesión_ibfk_2` FOREIGN KEY (`ID_persona`) REFERENCES `persona` (`ID_persona`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `inquietud`
--
ALTER TABLE `inquietud`
  ADD CONSTRAINT `fk_gentee` FOREIGN KEY (`ID_persona`) REFERENCES `persona` (`ID_persona`);

--
-- Filtros para la tabla `material_apoyo`
--
ALTER TABLE `material_apoyo`
  ADD CONSTRAINT `fk_per` FOREIGN KEY (`ID_persona`) REFERENCES `persona` (`ID_persona`);

--
-- Filtros para la tabla `pago`
--
ALTER TABLE `pago`
  ADD CONSTRAINT `fk_carrito` FOREIGN KEY (`ID_carrito`) REFERENCES `carrito_compras` (`ID_carrito`),
  ADD CONSTRAINT `fk_gente` FOREIGN KEY (`ID_persona`) REFERENCES `persona` (`ID_persona`);

--
-- Filtros para la tabla `persona`
--
ALTER TABLE `persona`
  ADD CONSTRAINT `fk_curso` FOREIGN KEY (`Codigo_curso`) REFERENCES `cursos` (`Codigo_curso`),
  ADD CONSTRAINT `fk_permisos` FOREIGN KEY (`ID_permisos`) REFERENCES `permisos` (`ID_permisos`),
  ADD CONSTRAINT `fk_rol` FOREIGN KEY (`ID_rol`) REFERENCES `rol` (`ID_rol`);

--
-- Filtros para la tabla `sesiones_en_linea`
--
ALTER TABLE `sesiones_en_linea`
  ADD CONSTRAINT `fk_personaa` FOREIGN KEY (`ID_persona`) REFERENCES `persona` (`ID_persona`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
